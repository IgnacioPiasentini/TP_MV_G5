history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
dpkg-reconfigure keyboard-configuration
dpkg-reconfigure keyboard-configuration
dpkg-reconfigure keyboard-configuration
setupcon
clear
vim /etc/hosts
hostname TPServer
exit
ls -l /root
apt-get update
apt update
apt list --upgradable 
sudo apt upgrade 
sudo apt autoremove 
apt update 
sudo apt upgrade -y
apt install apache2 php libapache2-mod-php -y
systemctl status apache2
systemctl status apache2
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
vim /etc/apache2/mods-enabled/dir.conf
systemctl restart apache2
apt update
ls -l /var/www/html/
apt install mariadb-server -y
systemctl status mariadb
mariadb < /root/Material_Adicional_TPVMCA/db.sql
mariadb
clear
mariadb
mariadb
clear
ip a
vim /etc/network/interfaces
vim /etc/network/interfaces
systemctl restart networking
ip a
ip route 
/etc/init.d/networking restart
ping 8.8.8.8
ping  -c 4 8.8.8.8
poweroff
lsblk
poweroff
lsblk
fdisk /dev/sdc
fdisk /dev/sdc
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
lsblk
mkdir /www_dir
mkdir /backup_dir
ls -l /root
ls -l /
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
vim /etc/fstab
mount -a
clear
apt install locate
updatedb
locate index.php
locate logo.png
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.png /www_dir/
ls -l /www_dir
vim /etc/apache2/sites-available/000-default.conf 
vim /etc/apache2/apache2.conf 
systemctl restart apache2
clear
poweroff 
touch /opt/particion
cat partitions.txt 
cat /proc/partitions 
cat /proc/partitions > /opt/particion 
cat /opt/particion 
cat /proc/partitions 
cat /opt/particion 
clear
mkdir /opt/scripts
vim /opt/scripts/backup_full.sh
vim /opt/scripts/backup_full.sh
clear
vim /opt/scripts/backup_full.sh
poweroff 
vim /opt/scripts/backup_full.sh
vim /opt/scripts/backup_full.sh
vim /opt/scripts/backup_full.sh
chown root /opt/scripts/backup_full.sh 
chmod 755 /opt/scripts/backup_full.sh 
crontab -e
vim /etc/crontab 
clear
vim /etc/crontab 
clear
vim /etc/crontab 
clear
poweroff 
vim /opt/scripts/backup_full.sh
clear
poweroff 
