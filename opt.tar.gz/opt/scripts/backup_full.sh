#! /bin/bash

FECHA=$(date +%Y%m%d)

ORIGEN=$1
DESTINO=$2

if [ "$ORIGEN" == "-help" ]; then
echo "==================================================="
echo "                      AYUDA                        "	
echo "==================================================="
echo "      Este script te permite crear backups         "
echo "        que se comprimen automaticamente           "
echo "==================================================="
echo "                 ¿Como se usa?                     "  
echo "==================================================="
echo " -----------Necesitas dos parametros---------------"
echo " " 
echo "Origen: el directorio que vas a hacer el backup    "
echo "Destino: directorio donde se guarda el archivo     "
echo " "
echo "Ejemplo: /opt/scripts/backup_full.sh origen destino"
echo "==================================================="

else 

if [ -z "$ORIGEN" ] || [ -z "$DESTINO" ]; then 
echo "==================================================="
echo "         ERROR: Faltan datos o Ingresaste mal      "
echo "==================================================="
echo " Guia rapida:                                      "
echo "     /opt/scripts/backup_full.sh [origen] [destino]" 
echo " "
echo " Para mas informacion:                             "
echo "     /opt/scripts/backup_full.sh -help             " 
echo "==================================================="

else

if [ -d "$ORIGEN" ]; then 
	echo "El directorio de origen existe"
else
	echo "El directorio de origen no existe"
fi

if [ -d "$DESTINO" ]; then
	echo "El directorio de destino existe"
else
	echo "El directorio de destino no existe"
fi 

if [ -d "$ORIGEN" ] && [ -d "$DESTINO" ];then
	tar -cfz "$DESTINO/bkp_$FECHA.tar.gz" "$ORIGEN"
	echo "EL archivo se guardo correctamente"
fi
fi
fi
